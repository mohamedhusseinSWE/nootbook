export const INFINITE_QUERY_LIMIT = 10;
