/**
 * Stripe utilities for subscription management
 */

import { auth } from "@/lib/auth-client";
import { db } from "@/db";
import Stripe from "stripe";

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2025-06-30.basil",
});

/**
 * Get user's subscription plan and status
 */
export async function getUserSubscriptionPlan() {
  const session = await auth();
  
  if (!session || !session.user) {
    return {
      isSubscribed: false,
      isCanceled: false,
      stripeCurrentPeriodEnd: null,
      planName: "free",
    };
  }

  const user = await db.user.findUnique({
    where: {
      id: session.user.id,
    },
    select: {
      stripeSubscriptionId: true,
      stripeCurrentPeriodEnd: true,
      stripeCustomerId: true,
      stripePriceId: true,
      planName: true,
      subscriptionStatus: true,
    },
  });

  if (!user) {
    return {
      isSubscribed: false,
      isCanceled: false,
      stripeCurrentPeriodEnd: null,
      planName: "free",
    };
  }

  const isSubscribed =
    user.stripePriceId &&
    user.stripeCurrentPeriodEnd &&
    user.stripeCurrentPeriodEnd.getTime() + 86_400_000 > Date.now() &&
    user.subscriptionStatus === "active";

  const plan = isSubscribed
    ? await db.plan.findFirst({
        where: {
          stripePriceId: user.stripePriceId!,
        },
      })
    : null;

  let isCanceled = false;
  if (isSubscribed && user.stripeSubscriptionId) {
    try {
      const subscription = await stripe.subscriptions.retrieve(
        user.stripeSubscriptionId
      );
      isCanceled = subscription.cancel_at_period_end;
    } catch (error) {
      console.error("Error fetching subscription:", error);
    }
  }

  return {
    ...plan,
    stripeSubscriptionId: user.stripeSubscriptionId,
    stripeCurrentPeriodEnd: user.stripeCurrentPeriodEnd,
    stripeCustomerId: user.stripeCustomerId,
    stripePriceId: user.stripePriceId,
    planName: user.planName || "free",
    subscriptionStatus: user.subscriptionStatus,
    isSubscribed: !!isSubscribed,
    isCanceled,
  };
}

/**
 * Create Stripe checkout session
 */
export async function createCheckoutSession(userId: string, planId: number) {
  const plan = await db.plan.findUnique({
    where: { id: planId },
  });

  if (!plan) {
    throw new Error("Plan not found");
  }

  const user = await db.user.findUnique({
    where: { id: userId },
    select: { email: true, stripeCustomerId: true },
  });

  if (!user) {
    throw new Error("User not found");
  }

  const session = await stripe.checkout.sessions.create({
    customer: user.stripeCustomerId || undefined,
    customer_email: !user.stripeCustomerId ? user.email : undefined,
    mode: "subscription",
    payment_method_types: ["card"],
    line_items: [
      {
        price: plan.stripePriceId!,
        quantity: 1,
      },
    ],
    success_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard?success=true`,
    cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/pricing?canceled=true`,
    metadata: {
      userId: userId,
      planId: planId.toString(),
    },
    subscription_data: {
      trial_period_days: plan.trialPeriodDays || undefined,
      metadata: {
        userId: userId,
        planId: planId.toString(),
      },
    },
  });

  return session;
}

/**
 * Create Stripe billing portal session
 */
export async function createBillingPortalSession(customerId: string) {
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/billing`,
  });

  return session;
}

