-- AlterTable
ALTER TABLE "Plan" ADD COLUMN     "numberOfFiles" INTEGER NOT NULL DEFAULT 0;
